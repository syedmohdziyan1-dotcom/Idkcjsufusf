#include <jni.h>
#include <string>

extern "C"
JNIEXPORT jstring JNICALL
Java_dev_pelican_installer_MainActivity_nativeStatus(JNIEnv* env, jobject) {
    const std::string status = "ARM64 native starter loaded in installer process";
    return env->NewStringUTF(status.c_str());
}
