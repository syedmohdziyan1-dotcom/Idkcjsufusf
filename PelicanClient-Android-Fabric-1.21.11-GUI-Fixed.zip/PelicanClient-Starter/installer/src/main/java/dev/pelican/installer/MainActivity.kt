package dev.pelican.installer

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import java.io.InputStream
import java.io.OutputStream

class MainActivity : Activity() {
    private lateinit var status: TextView
    private var selectedRoot: Uri? = null

    private val chooseFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            selectedRoot = uri
            status.text = "Selected folder:\\n$uri"
        }
    }

    private val chooseJar = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) installJar(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        System.loadLibrary("pelican_native")

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
        }
        status = TextView(this).apply { text = "Pelican Installer 0.1.0\nSelect a Minecraft instance folder." }
        val folderButton = Button(this).apply {
            text = "1. Select instance folder"
            setOnClickListener { chooseFolder.launch(null) }
        }
        val jarButton = Button(this).apply {
            text = "2. Select Pelican Fabric JAR and install"
            setOnClickListener {
                if (selectedRoot == null) {
                    Toast.makeText(this@MainActivity, "Select an instance folder first", Toast.LENGTH_SHORT).show()
                } else chooseJar.launch(arrayOf("application/java-archive", "application/octet-stream", "*/*"))
            }
        }
        val nativeButton = Button(this).apply {
            text = "Check native library"
            setOnClickListener {
                status.text = "Native library loaded: " + nativeStatus()
            }
        }
        layout.addView(status)
        layout.addView(folderButton)
        layout.addView(jarButton)
        layout.addView(nativeButton)
        setContentView(layout)
    }

    private fun installJar(source: Uri) {
        try {
            val root = DocumentFile.fromTreeUri(this, selectedRoot!!) ?: error("Cannot open selected folder")
            val mods = root.findFile("mods") ?: root.createDirectory("mods") ?: error("Cannot create mods folder")
            val target = mods.findFile("pelican-client.jar") ?: mods.createFile("application/java-archive", "pelican-client.jar")
                ?: error("Cannot create target JAR")
            contentResolver.openInputStream(source).use { input ->
                requireNotNull(input) { "Cannot read selected JAR" }
                contentResolver.openOutputStream(target.uri, "wt").use { output ->
                    requireNotNull(output) { "Cannot write destination JAR" }
                    input.copyTo(output)
                }
            }
            status.text = "Installed pelican-client.jar\nRestart MojoLauncher to load it."
        } catch (t: Throwable) {
            status.text = "Install failed: ${t.message}"
        }
    }


    private external fun nativeStatus(): String
}
