# Pelican Client — Android / Fabric 1.21.11 starter

This is a **starter source project**, not a finished 120-module client or a tested APK.
It contains:
- `fabric-mod/`: Fabric 1.21.11 client mod skeleton with a Right Shift screen and module registry.
- `installer/`: Android app skeleton using the Storage Access Framework to select a folder and copy the built Fabric JAR into its `mods` folder.
- `native/`: ARM64 JNI C++ library starter, built by the Android Gradle plugin for `arm64-v8a`.
- `.github/workflows/build.yml`: CI build for the Fabric JAR and Android debug APK.

## Requirements
- JDK 21
- Android Studio with Android SDK and NDK (for APK/native build)
- Gradle 8.14+ (or import into Android Studio and let it provision Gradle)
- Internet access for Gradle dependencies and Minecraft/Fabric artifacts

## Build
From the project root:
```bash
gradle :fabric-mod:build
gradle :installer:assembleDebug
```
Outputs:
- `fabric-mod/build/libs/`
- `installer/build/outputs/apk/debug/`

The Android installer copies the JAR chosen from Android's document picker into a folder the user selects with Android's Storage Access Framework. Select the actual Minecraft instance root (the folder containing `mods`) or its `mods` folder as appropriate; the app creates `mods` beneath the selected root.

## Important Android / MojoLauncher notes
- This is a supported Fabric mod installer, **not arbitrary process injection**. Android apps cannot generally write into another app's private data directory. The user must select a folder Android exposes through the Storage Access Framework; some launcher-private locations may not be selectable.
- The native library is an ARM64 JNI starter compiled into the installer APK. This starter does not yet establish a cross-process native loading path into MojoLauncher. The Fabric mod currently runs Java-side and will still work without the native library.
- No MinHook: it is Windows-specific and is not used here.
- No gameplay cheats are implemented in this starter. It provides the mod/installer/native scaffolding and a harmless GUI toggle example.
- Verify exact Fabric Loader / Fabric API availability for Minecraft 1.21.11 in your target MojoLauncher installation.

## Next development milestone
First get the Fabric mod to load and the installer to copy it into a user-selected instance. Then test JNI/native loading inside the actual MojoLauncher game process before adding more modules.
