package dev.pelican.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class PelicanScreen extends Screen {
    protected PelicanScreen() {
        super(Component.literal("Pelican Client"));
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        this.renderBackground(graphics, mouseX, mouseY, delta);
        int centerX = this.width / 2;
        int centerY = this.height / 2;
        graphics.fill(centerX - 110, centerY - 75, centerX + 110, centerY + 75, 0xE8202028);
        graphics.drawCenteredString(this.font, "PELican CLIENT", centerX, centerY - 55, 0xFFFFFFFF);
        graphics.drawCenteredString(this.font, "Starter GUI - Right Shift", centerX, centerY - 30, 0xFFB8B8FF);
        graphics.drawCenteredString(this.font, "Module framework is the next milestone", centerX, centerY + 5, 0xFFFFFFFF);
        graphics.drawCenteredString(this.font, "Press ESC to close", centerX, centerY + 48, 0xFFCCCCCC);
        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
